package final1;

public class Data {
    public int value;
}
