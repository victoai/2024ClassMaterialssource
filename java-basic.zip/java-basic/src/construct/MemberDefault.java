package construct;

public class MemberDefault {
    String name;

}
