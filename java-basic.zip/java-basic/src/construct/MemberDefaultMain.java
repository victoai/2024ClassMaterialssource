package construct;

public class MemberDefaultMain {

    public static void main(String[] args) {
        MemberDefault memberDefault = new MemberDefault();
    }
}
