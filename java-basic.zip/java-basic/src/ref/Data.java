package ref;

public class Data {
    int value;
}
