package ref.ex;

public class ProductOrder {
    String productName;
    int price;
    int quantity;
}
