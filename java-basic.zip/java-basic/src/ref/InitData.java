package ref;

public class InitData {
    int value1; //초기화 하지 않음
    int value2 = 10;//10으로 초기화
}
