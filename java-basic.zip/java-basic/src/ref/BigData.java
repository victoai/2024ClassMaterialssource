package ref;

public class BigData {
    Data data; //null
    int count; //0
}
