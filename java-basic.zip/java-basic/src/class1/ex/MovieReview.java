package class1.ex;

public class MovieReview {
    String title;
    String review;
}
