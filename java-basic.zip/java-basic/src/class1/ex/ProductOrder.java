package class1.ex;

public class ProductOrder {
    String productName;
    int price;
    int quantity;
}
