package class1;

public class Student {
    String name;
    int age;
    int grade;
}
