package poly.ex2;

public class Duck extends Animal {
    @Override
    public void sound() {
        System.out.println("꽉꽉");
    }
}
