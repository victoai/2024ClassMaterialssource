package poly.ex2;

public class Pig extends Animal {
    //sound 해야 하는데...
}
