package poly.ex6;

public interface Fly {
    void fly();
}
