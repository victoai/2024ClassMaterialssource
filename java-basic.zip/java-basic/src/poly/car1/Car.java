package poly.car1;

public interface Car {
    void startEngine();
    void offEngine();
    void pressAccelerator();
}
