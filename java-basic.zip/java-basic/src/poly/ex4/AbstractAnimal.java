package poly.ex4;

public abstract class AbstractAnimal {
    public abstract void sound();
    public abstract void move();
}
