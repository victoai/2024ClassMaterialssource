package poly.ex5;

public interface InterfaceAnimal {
    void sound(); //public abstract
    void move();  //public abstract
}
