package poly.ex1;

public class Cat {

    public void sound() {
        System.out.println("냐옹");
    }
}
