package poly.diamond;

public interface InterfaceA {
    void methodA();
    void methodCommon();
}
