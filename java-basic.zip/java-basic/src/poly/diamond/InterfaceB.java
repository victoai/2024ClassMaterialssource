package poly.diamond;

public interface InterfaceB {
    void methodB();
    void methodCommon();
}
