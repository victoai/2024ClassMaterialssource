package poly.ex.sender;

public interface Sender {
    void sendMessage(String message);
}
