package poly.ex.pay1;

public interface Pay {
    boolean pay(int amount);
}
