package pack;

public class Data {
    public Data() {
        System.out.println("패키지 pack Data 생성");
    }
}
