package pack.b;

public class User {

    public User() {
        System.out.println("패키지 pack.b 회원 생성");
    }
}
