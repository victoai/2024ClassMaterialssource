package oop1;

public class MusicPlayerData {
    int volume = 0;
    boolean isOn = false;
}
