package static1;

public class Counter {
    public int count;
}
