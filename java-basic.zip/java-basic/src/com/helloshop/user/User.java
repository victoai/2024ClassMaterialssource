package com.helloshop.user;

public class User {
    String userId;
    String name;
}
