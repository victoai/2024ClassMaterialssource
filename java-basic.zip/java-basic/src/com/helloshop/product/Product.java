package com.helloshop.product;

public class Product {
    String productId;
    int price;
}
