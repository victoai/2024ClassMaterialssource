package com.helloshop.product;

public class ProductService {
}
