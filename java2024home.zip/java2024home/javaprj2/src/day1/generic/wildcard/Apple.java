package day1.generic.wildcard;

public class Apple extends Fruit {

}
