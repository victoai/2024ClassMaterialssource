package day1.generic.printer;

public class Material {

}
