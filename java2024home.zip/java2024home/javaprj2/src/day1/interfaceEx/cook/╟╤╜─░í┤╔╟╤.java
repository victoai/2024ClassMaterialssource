package day1.interfaceEx.cook;

interface 한식가능한{
   
    public String  비빔밥만들기();

}