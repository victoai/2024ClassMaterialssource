package day1.interfaceEx.cook;

public class SampleCook3  extends Cook implements 중식가능한 {

	 

	public SampleCook3(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String 탕수육만들기() {
		// TODO Auto-generated method stub
		return "새콤달콤탕수육";
	}

}
