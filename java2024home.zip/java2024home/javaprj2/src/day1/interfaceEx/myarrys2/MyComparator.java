package day1.interfaceEx.myarrys2;

public interface MyComparator {
	int compare(Object o1, Object o2);
}
