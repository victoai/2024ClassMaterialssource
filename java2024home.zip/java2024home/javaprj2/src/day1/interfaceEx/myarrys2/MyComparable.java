package day1.interfaceEx.myarrys2;

public interface MyComparable {
	int compareTo(Object obj);
}
