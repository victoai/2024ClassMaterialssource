package day2.lamda.functionalI;

public class B {

}
