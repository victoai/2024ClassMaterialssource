package day4.계산기;

public interface Calculator {
	
	int add( int su1, int su2);

}
