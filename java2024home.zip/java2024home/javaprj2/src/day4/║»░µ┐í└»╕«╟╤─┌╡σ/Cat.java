package day4.변경에유리한코드;

public class Cat  extends Animal {
	
	@Override
	 public void bark() {
		 System.out.println("야옹");
	 }

}
