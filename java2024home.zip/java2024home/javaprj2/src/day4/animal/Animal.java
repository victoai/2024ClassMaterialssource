package day4.animal;

public class Animal {	
	public void bark() {  
		  
	}
}
