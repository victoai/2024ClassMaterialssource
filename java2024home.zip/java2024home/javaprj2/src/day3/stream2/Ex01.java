package day3.stream2;

public class Ex01 {

	public static void main(String[] args) {
		 
	}

}
