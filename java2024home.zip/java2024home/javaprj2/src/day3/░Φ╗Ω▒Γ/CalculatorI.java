package day3.계산기;

public interface CalculatorI {
	public int add( int a, int b);
	public int sub( int a, int b);
}
