package day3.animal;

public class Ex01 {

	public static void main(String[] args) {
		 
	//	Cat cat = new Cat();
   //   cat.bark();
		Dog dog  = new Dog();
		dog.bark();		
		
   //  	Cat cat2 = new Cat();
   //  	cat2.bark();
		
		Dog dog2  = new Dog();
		dog2.bark();		
		     	
	}
}
