package day3.funInterface;

public class A {
	
	
	public String   레시피만들기() {
		return "  레시피";
	}

}
