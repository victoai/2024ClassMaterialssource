package 복습및정리.객체지향.상속;

public class B {
	void 공부하기() {
		System.out.println("공부하기");
	}
}
