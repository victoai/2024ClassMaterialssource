package 복습및정리.객체지향.다형성;

public class Dog extends Animal {
@Override
void 짖다() {
	// TODO Auto-generated method stub
	 System.out.println("멍멍");
}
}
