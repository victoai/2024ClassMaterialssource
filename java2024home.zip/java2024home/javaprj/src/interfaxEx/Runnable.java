package interfaxEx;

public interface  Runnable{
    void run();
}
