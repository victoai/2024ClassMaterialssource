package interfaxEx;

public class RunnableWjy  implements Runnable {

	@Override
	public void run() {
		 System.out.println( " run run !!!  right now");		
	}

}
