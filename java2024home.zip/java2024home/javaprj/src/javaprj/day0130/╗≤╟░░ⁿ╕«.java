package javaprj.day0130;

public class 상품관리 {

	public static void main(String[] args) {
		 
		
		String[] goods = new String[5];
		
		
		System.out.println( "상품관리화면입니다. ");
		while(true) {
			
			System.out.println( "메뉴 ");
			
			
		}

	}

}
