package javaprj.day0207.equals오버라이드복습;

public class 박태민_음료상속 extends Student{

	public void 음료마시기(){
        System.out.println(" 학생은 아메리카노를 마시고싶드악");
 }
}