package javaprj.day0207.equals오버라이드복습;

public class Kjy extends Student {

	@Override
	public void 음료마시기() {
		System.out.println("아메리카노");
	}
}
