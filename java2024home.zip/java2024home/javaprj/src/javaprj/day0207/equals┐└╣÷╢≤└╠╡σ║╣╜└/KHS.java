package javaprj.day0207.equals오버라이드복습;

public class KHS extends Student {
	
	public void  음료마시기(){
        System.out.println("현수는 따뜻한 티를 마신다.");
 }

}
