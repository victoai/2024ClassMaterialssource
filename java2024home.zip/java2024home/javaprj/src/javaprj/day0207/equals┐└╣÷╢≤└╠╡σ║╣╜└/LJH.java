package javaprj.day0207.equals오버라이드복습;

public class LJH extends Student{

	public void 음료마시기() {
		System.out.println("이정훈은 초코머시기음료를 마신다");
	}
}
