package javaprj.day0207.equals오버라이드복습;
public class Student_yj extends Student{
	
	@Override
	public void 음료마시기() {
		System.out.println("나는 초코라떼");
	}

}
