package javaprj.day0207.equals오버라이드복습;

public class SYJ extends Student{
@Override
	public void 음료마시기() {
		System.out.println("바닐라라떼 마시면 안될까요ㅎㅎ");
	}
}
