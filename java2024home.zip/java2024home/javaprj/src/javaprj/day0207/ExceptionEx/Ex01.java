package javaprj.day0207.ExceptionEx;

public class Ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr = new int[3];		
		arr[3]=50;		
		System.out.println( arr[3]);
		
		System.out.println(" 정상종료");

	}

}
