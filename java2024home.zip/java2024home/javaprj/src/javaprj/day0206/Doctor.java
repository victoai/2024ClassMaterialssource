package javaprj.day0206;

public class Doctor {

}
