package javaprj.day0206;

public class 업캐스팅다운캐스팅 {
	  public static void main(String[] args) {
		
		  
		  
		  
		  Object o   =   new Cat();
		  
		  
		  Runnable  r =  (Runnable) o;
		  
		 
		  
		  
		  Doctor d  = new Doctor();
		//  Person p =  (Person)d;
		  
		  
		  Cat cat = new Cat();
		   
		   
	}

}
