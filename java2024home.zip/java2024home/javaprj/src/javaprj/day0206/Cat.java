package javaprj.day0206;

public class Cat implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
