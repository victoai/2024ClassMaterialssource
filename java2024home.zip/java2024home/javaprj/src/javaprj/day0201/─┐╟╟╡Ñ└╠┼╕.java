package javaprj.day0201;

public  class 커피데이타 {
	int 설탕 = 1000; // 숫자
	int 프리마 = 1000; // 숫자
	int 원두 = 1000;
	int 물 = 10000;
	int 매출금액 = 0;
}

 