package javaprj.day0205.다형성예제;

public class 하와이안피자 extends Pizza {
	
	public void 파인애플() {
		System.out.println("파인애플");
	}

	public void 양파() {
		System.out.println("양파제외");
	}
	public void 올리브() {
		System.out.println("올리브 제외");
	}

	public void 페퍼로니() {
		System.out.println("페퍼로니");
	}
	public void 토마토소스() {
		System.out.println("토마토소스");
	}
	public void 소시지() {
		System.out.println("소시지제외");
	}

}
