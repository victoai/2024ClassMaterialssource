package MyArrays;

public interface MyComparable {
	int compareTo(Object obj);   // 자기자신과 다른 객체 비교후 양수 또는 음수를 반환하는 매서드를 작성하시오 , 정렬알고리즘은 반환값이 양수일때 자리바꿈이 일어남
}
