package day1.interfaceEx.cook;

interface 일식가능한{ 
    public String  초밥만들기(); 
}

