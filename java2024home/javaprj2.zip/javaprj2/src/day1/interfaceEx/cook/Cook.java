package day1.interfaceEx.cook;

class Cook{
    String name;
   
	public Cook(String name ) {
		super();
		this.name = name;
		 
	}
	@Override
	public String toString() {
		return "Cook [name=" + name + " ]";
	}
     
    
  
}
