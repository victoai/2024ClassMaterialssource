package day1.generic.generictest;

public class Apple extends Fruit {

}
