package day1.generic.generictest;

public class Fruit {

}
