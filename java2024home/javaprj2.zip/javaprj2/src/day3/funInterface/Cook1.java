package day3.funInterface;

import java.util.function.Supplier;

public class Cook1   implements Supplier<String >{

	@Override
	public String get() {
		// TODO Auto-generated method stub
		return "  회덮밥 레시피 제공하기 ";
	}
	

}
