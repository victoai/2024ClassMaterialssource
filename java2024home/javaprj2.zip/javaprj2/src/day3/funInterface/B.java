package day3.funInterface;

public class B {

}
