package day3.animal;


public class Animal {	
	public void bark() {  
		  
	}
}
