package day5.interfaceEx.학생.김병진;

public class LibMain {

	public static void main(String[] args) {
		
		LibA program = new LibA();		
		program.forStart();
		program.forCharacter("A");
		program.Something(program);
	}
}
