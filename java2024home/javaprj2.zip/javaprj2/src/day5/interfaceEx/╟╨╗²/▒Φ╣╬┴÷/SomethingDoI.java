package day5.interfaceEx.학생.김민지;

public interface SomethingDoI {
  public void doing();
}
