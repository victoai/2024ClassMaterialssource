package day5.재귀호출;

public class 재귀호출이란 {

	public static void main(String[] args) {
		 
		
		System.out.println("재귀호출이란? 자기자신을 호출하는 것을 말한다.");
		System.out.println("주의사항 !! 반드시 종료 조건이 있어야 한다.");
		
		
		// 1부터 10까지 합
		
		
	
		
		// 1~10까지 합 함수만들기
		
		
		
		
		
		// 1~10까지 합 재귀함수로 만들기
		
		
		
	}

	
	
	
	
}
