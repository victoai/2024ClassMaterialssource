package day4.animal;

public class Ex02 {

	public static void main(String[] args) {

	     Animal animal  = new Cat();  // new Dog();		
	     animal.bark();
		 Animal animal2  = new Cat(); // new Dog();		
		 Animal animal3  = new Cat(); // new Dog();
		 Animal animal4  = new Cat(); // new Dog();

	} 

}
