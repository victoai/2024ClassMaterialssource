package day2.lamda.학생;

public class Good {
	
	String name;
	int price;
	int count;
	
	
	public Good(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "Good [name=" + name + ", price=" + price + "]";
	}
	
	
	

}
